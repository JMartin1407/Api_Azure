// server.js
const express = require('express');
const cors = require('cors');
const multer = require('multer');
const XLSX = require('xlsx');
require('dotenv').config();

const { Usuario, AlumnoDB, NotaDB, AnalisisResultadoDB, initDbUser, testConnection } = require('./database');
const { runAnalysisLogic, MATERIAS } = require('./analisis');

const app = express();
const PORT = process.env.PORT || 3000;

// --- MIDDLEWARES ---
// 🔥 CORS corregido con el dominio real de Azure
const allowedOrigins = [
  'https://gray-beach-0cdc4470f.3.azurestaticapps.net',
  'https://blue-sea-02785951e.3.azurestaticapps.net', // ← CORRECTO
  'http://localhost:3000',
  'http://localhost:5173',
  'http://localhost:4200',
  'http://localhost:3001'
];

app.use(cors({
  origin: function (origin, callback) {
    // Permitir requests sin origin (como Postman o curl)
    if (!origin) return callback(null, true);

    if (allowedOrigins.includes(origin)) {
      callback(null, true);
    } else {
      console.log('❌ Origen bloqueado por CORS:', origin);
      callback(new Error('No permitido por CORS'));
    }
  },
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With'],
  exposedHeaders: ['Content-Range', 'X-Content-Range']
}));

// 🔥 Necesario para que Azure acepte el preflight OPTIONS
app.options('*', cors());

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Configuración de Multer
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 }
});

// --- MIDDLEWARE DE AUTENTICACIÓN ---
async function authenticateToken(req, res, next) {
  const authHeader = req.headers['authorization'];

  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ detail: 'Token inválido' });
  }

  const token = authHeader.split(' ')[1];

  try {
    const user = await Usuario.findOne({ where: { email: token } });

    if (!user) {
      return res.status(401).json({ detail: 'Token inválido' });
    }

    req.user = {
      email: user.email,
      rol: user.rol,
      nombre: user.nombre,
      id: user.id
    };

    next();
  } catch (error) {
    console.error('Error en autenticación:', error);
    return res.status(500).json({ detail: 'Error en autenticación' });
  }
}

// --- MIDDLEWARE DE PERMISOS ---
function checkPermission(requiredRole) {
  return (req, res, next) => {
    if (req.user.rol !== requiredRole) {
      return res.status(403).json({ detail: 'Acceso denegado' });
    }
    next();
  };
}

// --- RUTAS ---
app.get('/', (req, res) => {
  res.json({
    message: 'API de Análisis Académico - Express/Node.js',
    version: '1.0.0',
    endpoints: {
      health: '/health',
      login: '/auth/login',
      upload: '/admin/upload-and-analyze/',
      dashboards: {
        admin: '/admin/dashboard/',
        docente: '/docente/dashboard/'
      }
    },
    status: 'running'
  });
});

app.get('/health', (req, res) => {
  res.json({ status: 'ok', message: 'Backend API is running' });
});

// --- LOGIN ---
app.post('/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ detail: 'Email y password son requeridos' });
    }

    const user = await Usuario.findOne({ where: { email } });

    if (!user || user.password !== password) {
      return res.status(400).json({ detail: 'Credenciales incorrectas' });
    }

    res.json({
      token: user.email,
      rol: user.rol,
      nombre: user.nombre,
      id: user.id
    });

  } catch (error) {
    console.error('Error en login:', error);
    res.status(500).json({ detail: 'Error en el servidor' });
  }
});

// --- UPLOAD Y ANÁLISIS (Admin) ---
app.post('/admin/upload-and-analyze/', authenticateToken, checkPermission('Admin'), upload.single('file'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ detail: 'No se proporcionó ningún archivo' });
    }

    const workbook = XLSX.read(req.file.buffer, { type: 'buffer' });
    const sheetName = workbook.SheetNames[0];
    const worksheet = workbook.Sheets[sheetName];
    const data = XLSX.utils.sheet_to_json(worksheet);

    if (!data || data.length === 0) {
      return res.status(400).json({ detail: 'El archivo está vacío o no tiene el formato correcto' });
    }

    const resultados = runAnalysisLogic(data);
    const df_procesado = resultados.df_procesado;

    const alumnos = df_procesado.slice(0, 10).map(row => {
      const detalle_promedios_por_materia = {};
      MATERIAS.forEach(m => {
        const key = `${m.toLowerCase()}_promedio`;
        detalle_promedios_por_materia[m] = parseFloat(row[key]) || 0;
      });

      return {
        id: row.id,
        nombre: row.nombre || 'Sin nombre',
        promedio_gral_calificacion: parseFloat(row.promedio_gral_calificacion) || 0,
        promedio_gral_asistencia: parseFloat(row.promedio_gral_asistencia) || 0,
        promedio_gral_conducta: parseFloat(row.promedio_gral_conducta) || 0,
        detalle_promedios_por_materia,
        area_de_progreso: parseFloat(row.area_de_progreso) || 0,
        probabilidad_riesgo: parseFloat(row.probabilidad_riesgo) || 0,
        vector_magnitud: parseFloat(row.vector_magnitud) || 0,
        recomendacion_pedagogica: row.recomendacion_pedagogica || 'N/A',
        materia_critica_temprana: row.materia_critica_temprana || 'N/A'
      };
    });

    const area_prom = df_procesado.reduce((acc, x) => acc + (x.area_de_progreso || 0), 0) / df_procesado.length;

    res.json({
      message: 'Análisis completado exitosamente',
      promedio_general: resultados.promedio_general,
      area_de_progreso_grupo: parseFloat(area_prom.toFixed(2)),
      correlaciones: resultados.correlaciones,
      estadistica_grupal: resultados.estadistica_grupal,
      data_preview: alumnos
    });

  } catch (error) {
    console.error('Error en upload-and-analyze:', error);
    res.status(500).json({ detail: error.message });
  }
});

// --- DASHBOARD ADMIN ---
app.get('/dashboard/admin', authenticateToken, checkPermission('Admin'), (req, res) => {
  res.json({
    message: `Bienvenido ${req.user.nombre}`,
    data: {}
  });
});

// --- DASHBOARD DOCENTE ---
app.get('/dashboard/docente', authenticateToken, checkPermission('Docente'), (req, res) => {
  res.json({
    message: `Bienvenido ${req.user.nombre}`,
    data: {}
  });
});

// --- INICIAR SERVIDOR ---
async function startServer() {
  try {
    const connected = await testConnection();

    if (connected) {
      await initDbUser();
    } else {
      console.warn('⚠️ No se pudo conectar a la base de datos.');
    }

    app.listen(PORT, () => {
      console.log(`\n🚀 Servidor Express corriendo en http://localhost:${PORT}`);
    });

  } catch (error) {
    console.error('❌ Error al iniciar:', error);
    process.exit(1);
  }
}

startServer();

module.exports = app;
